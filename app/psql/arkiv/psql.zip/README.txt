Observera att ni inte kommer �t databasen som �r skapad.

�ndra namn p� den i "create_db.sql" och skapa en ny om ni k�r p� egen dator.
Kom ih�g att k�ra "DROP DATABASE {namn}" efter�t.